var menu = document.getElementById('container-menu');
var cerrar = document.getElementById('cerrar');
var navbarNav = document.getElementById('navbarNav');

function mostrar(){
    menu.style.padding = '26px 26px 200vw 200vw';
    cerrar.style.display = 'block';
    navbarNav.style.display = 'flex';
}

function ocultar(){
    menu.style.padding = '26px';
    cerrar.style.display = 'none';
    navbarNav.style.display = 'none';
}